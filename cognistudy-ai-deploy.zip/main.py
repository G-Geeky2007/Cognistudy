"""
COGNISTUDY AI - FASTAPI BACKEND
Handles study history persistence using a local SQLite database (cognistudy.db)
and robust server-side PDF text extraction using PyMuPDF (fitz).
Supports local development and tunneling services (Cloudflare Tunnels, ngrok).
"""

import sqlite3
import os
import re
from contextlib import asynccontextmanager
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, HTTPException, status, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# Try importing PyMuPDF (fitz)
try:
    import fitz  # PyMuPDF
except ImportError:
    fitz = None

# Database configuration
DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cognistudy.db")


def get_db_connection() -> sqlite3.Connection:
    """Creates a connection to the SQLite database with dictionary-like row factory."""
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Initializes the SQLite schema if it does not already exist."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS study_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                topic TEXT NOT NULL,
                activity_type TEXT NOT NULL,
                score INTEGER,
                studied_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.commit()


def clean_pdf_text(raw_text: str) -> str:
    """
    Cleans raw extracted PDF text using regex:
    1. Rejoin hyphenated words split across line breaks (e.g., 'thermo-\ndynamics' -> 'thermodynamics').
    2. Replace single mid-paragraph newlines with spaces while preserving paragraph breaks ('\n\n').
    3. Collapse multiple consecutive spaces into a single space.
    """
    if not raw_text:
        return ""

    # Normalize line endings
    text = raw_text.replace("\r\n", "\n").replace("\r", "\n")

    # Rejoin hyphenated words split across line breaks
    text = re.sub(r'(\b\w+)-\s*\n\s*(\w+\b)', r'\1\2', text)

    # Split into paragraphs by double (or more) newlines
    paragraphs = re.split(r'\n{2,}', text)
    cleaned_paras = []
    for para in paragraphs:
        # Replace single mid-paragraph newlines with a single space
        cleaned_para = re.sub(r'\s*\n\s*', ' ', para)
        # Collapse multiple consecutive spaces/tabs into a single space
        cleaned_para = re.sub(r'[ \t]+', ' ', cleaned_para).strip()
        if cleaned_para:
            cleaned_paras.append(cleaned_para)

    return "\n\n".join(cleaned_paras).strip()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan event handler to ensure DB tables are ready on startup."""
    init_db()
    yield


# FastAPI Application instance
app = FastAPI(
    title="CogniStudy AI Backend",
    description="FastAPI service for study history tracking with SQLite and PyMuPDF text extraction.",
    version="1.1.0",
    lifespan=lifespan,
)

# CORS Configuration
# Allows requests from localhost (Live Server on 5500/3000/8000) and external domains (Vercel, Cloudflare, ngrok)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Pydantic Schemas for Request & Response Validation
class StudySessionCreate(BaseModel):
    topic: str = Field(..., min_length=1, description="Study topic or deck title")
    # Supports both camelCase (from frontend JSON) and snake_case
    activity_type: Optional[str] = Field(None, alias="activityType")
    score: Optional[int] = Field(None, ge=0, le=100, description="Optional quiz score (0-100)")

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "topic": "Cellular Biology Fundamentals",
                "activityType": "Quiz",
                "score": 90
            }
        }
    }


class StudySessionResponse(BaseModel):
    id: int
    topic: str
    activity_type: str
    score: Optional[int] = None
    studied_at: str


# API Endpoints
@app.get("/", tags=["Health"])
async def root():
    """Basic health check endpoint."""
    return {
        "status": "ok",
        "service": "CogniStudy AI Backend",
        "version": "1.1.0",
        "pdf_parser": "PyMuPDF (fitz)" if fitz else "PyMuPDF not installed"
    }


@app.post("/api/extract-pdf", tags=["PDF Extraction"])
async def extract_pdf(file: UploadFile = File(...)) -> Dict[str, Any]:
    """
    Extracts, orders, and cleans text from an uploaded PDF file using PyMuPDF (fitz).
    Rejoins hyphenated line wraps and preserves natural paragraph flow.
    """
    if fitz is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="PyMuPDF is not installed on the server. Please run: pip install pymupdf python-multipart"
        )

    # Validate file extension
    filename = file.filename or ""
    if not filename.lower().endswith(".pdf"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid file format. Please upload a PDF file (.pdf)."
        )

    try:
        pdf_bytes = await file.read()
        if not pdf_bytes:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="The uploaded PDF file is empty."
            )

        # Open PDF document from memory bytes stream
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
        total_pages = len(doc)

        extracted_pages = []
        for page in doc:
            # sort=True extracts text in natural geometric top-to-bottom reading order
            page_text = page.get_text("text", sort=True)
            if page_text:
                extracted_pages.append(page_text)

        doc.close()

        raw_full_text = "\n\n".join(extracted_pages)
        cleaned_text = clean_pdf_text(raw_full_text)

        # Scanned / Image-only PDF detection
        if not cleaned_text:
            return {
                "success": False,
                "error": "No selectable text found. This appears to be a scanned/image PDF."
            }

        return {
            "success": True,
            "text": cleaned_text,
            "pages": total_pages
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to extract text from PDF: {str(exc)}"
        )


@app.post("/api/history", status_code=status.HTTP_201_CREATED, tags=["Study History"])
async def record_study_session(session: StudySessionCreate) -> Dict[str, Any]:
    """
    Records a new study session (Quiz, Flashcard, or Summary) into SQLite.
    Accepts JSON body: { "topic": "...", "activityType": "...", "score": 90 }
    """
    activity_type_val = session.activity_type or "General"

    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO study_history (topic, activity_type, score)
                VALUES (?, ?, ?)
                """,
                (session.topic.strip(), activity_type_val.strip(), session.score),
            )
            conn.commit()
            record_id = cursor.lastrowid

        return {"success": True, "id": record_id}
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to record study session: {str(exc)}"
        )


@app.get("/api/history", response_model=List[StudySessionResponse], tags=["Study History"])
async def get_study_history():
    """
    Fetches all study sessions ordered by studied_at DESC.
    Returns JSON array of objects.
    """
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT id, topic, activity_type, score, studied_at
                FROM study_history
                ORDER BY studied_at DESC
                """
            )
            rows = cursor.fetchall()

            history = []
            for r in rows:
                history.append(
                    {
                        "id": r["id"],
                        "topic": r["topic"],
                        "activity_type": r["activity_type"],
                        "score": r["score"],
                        "studied_at": str(r["studied_at"]),
                    }
                )

        return history
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch study history: {str(exc)}"
        )


if __name__ == "__main__":
    import uvicorn
    # Local dev server execution
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
